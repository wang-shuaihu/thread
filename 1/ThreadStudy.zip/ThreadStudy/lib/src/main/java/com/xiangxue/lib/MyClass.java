package com.xiangxue.lib;

public class MyClass {
}
