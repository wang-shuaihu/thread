package demo6;

public class aba {
}
